<template>
  <div class="text-content">
    <h1>Your Friends</h1>

    <div class="center">
      <button class="referal">Your referal</button>
    </div>

    <h3>No friends yet</h3>

    <ul class="list">
      <li class="list-item">
        Maximilian
        <span class="list-btn done">50</span>
      </li>
    </ul>
  </div>
</template>
